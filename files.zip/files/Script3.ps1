#Huidige versie v0.1

#versie v0.1, script is aangemaakt, RRAS wordt geconfigureerd
#Printer wordt gepubliceerd, reverse lookup zone in DNS wordt gemaakt, DHCP wordt geautoriseerd
#PRT wordt gemaakt voor DC162910
#versie v1.0, Eindversie

#Router and remote access wordt geconfigureerd
Install-RemoteAccess -VpnType RoutingOnly

# Variabelen worden gedefinieerd 
$ExternalInterface = "WAN"
$InternalInterface = "LAN"

Write-Host -ForegroundColor Green -Object "Router and remote access wordt geconfigureerd"
cmd.exe /c "netsh routing ip nat install"
cmd.exe /c "netsh routing ip nat add interface $ExternalInterface"
cmd.exe /c "netsh routing ip nat set interface $ExternalInterface mode=full"
cmd.exe /c "netsh routing ip nat add interface $InternalInterface"


#Printer wordt gepubliceerd in de AD
Write-Host -ForegroundColor Green -Object "Printer wordt gepubliceerd in de AD"
Set-Printer -Name "Printer" -Published $True

#DHCP Server wordt geautoriseerd
Write-Host -ForegroundColor Green -Object "DHCP server wordt geautoriseerd"
Add-DhcpServerInDC -DnsName "dc162910.aventusrocks162910.local" -IPAddress 172.16.2.10

#DNS reverse lookup zone aanmaken
Add-DnsServerPrimaryZone -NetworkID “172.16.2.0/24” -ReplicationScope "Forest"

#Add PRT record voor de DC162910 record in DNS
Write-Host -ForegroundColor Green -Object "Een PRT wordt gemaakt voor de record DC162910"
Add-DnsServerResourceRecordPtr -Name "10" -ZoneName "2.16.172.in-addr.arpa" -AllowUpdateAny -TimeToLive 01:00:00 -AgeRecord -PtrDomainName "dc162910.AventusRocks162910.local"