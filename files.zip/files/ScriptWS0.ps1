#Huidige versie v0.1

#versie v0.1, script is aangemaakt
#versie v0.2, LAN netwerk is geautomatiseerd
#versie v0.3, LAN gedeelte is aangepast, WAN interface wordt ingesteld, DNS LAN, installatie AD en DNS
#versie v1.0, fine tunes, eind versie

#IPLAN wordt gedefenieerd
$IPLAN = "172.16.2.10"
#De DNS worden gedefenieerd
$DNS1LAN = "1.1.1.1"
$DNS2LAN = "8.8.8.8"
$Password = "Pa$$w0rd"
$user = "Mayar"

#Hiermee wordt de timezone ingesteld in Europe standart time UTC +1
Set-TimeZone -Id "W. Europe Standard Time"

#De inhoud van de object wordt geprint in groene tekst
Write-host -ForegroundColor green -Object "De LAN interface wordt geconfigureerd"
#Hier wordt de DHCP uitgeschakeld op LAN adapter
Set-NetIPInterface -InterfaceAlias LAN -Dhcp Enabled
#De interface wordt hernoemd naar LAN
Rename-NetAdapter “Ethernet0” -NewName “LAN"

#Windows auto Update wordt uitgeschakeld
sc.exe config wuauserv start= disabled
sc.exe stop wuauserv

#Nieuwe admin gebruiker wordt aangemaakt
New-LocalUser $user -FullName $user -Password (convertto-securestring $Password -AsPlainText -Force)
Add-LocalGroupMember -Group "Administrators" -Member $user

#De Computer naam wordt aangepast naar WS162910
Rename-Computer -NewName WS162910

Write-host -ForegroundColor red -Object "Computer gaat opnieuw opstarten binnen 15 sec"
Start-Sleep -Seconds 15
Restart-Computer