#Huidige versie v1.0

#versie v0.1, script is aangemaakt
#versie v0.2, LAN netwerk is geautomatiseerd
#versie v0.3, LAN gedeelte is aangepast, WAN interface wordt ingesteld, DNS LAN, installatie AD en DNS
#versie v1.0, fine tunes, eind versie

#IPLAN wordt gedefenieerd
$IPLAN = "172.16.2.10"
#De DNS worden gedefenieerd
$DNS1LAN = "1.1.1.1"
$DNS2LAN = "8.8.8.8"


#De inhoud van de object wordt geprint in groene tekst
Write-host -ForegroundColor green -Object "De LAN interface wordt geconfigureerd"
#Hier wordt de LAN adapter geconfigureerd
New-NetIPAddress -InterfaceAlias "Ethernet0" -IPAddress $IPLAN -PrefixLength 24
#Hier wordt de DHCP uitgeschakeld op LAN adapter
Set-NetIPInterface -InterfaceAlias LAN -Dhcp Disabled
#De interface wordt hernoemd naar LAN
Rename-NetAdapter “Ethernet0” -NewName “LAN"


#De inhoud van de object wordt geprint in groene tekst
Write-host -ForegroundColor green -Object "De DNS voor de LAN wordt ingesteld"
#De DNS wordt ingesteld
Set-DnsClientServerAddress -InterfaceAlias "LAN" -ServerAddresses ($DNS1LAN, $DNS2LAN)


#De inhoud van de object wordt geprint in groene tekst
Write-host -ForegroundColor green -Object "De WAN interface wordt nu geconfigureerd"
#De interface WAN wordt geinstalleerd op DHCP
Set-NetIPInterface -InterfaceAlias Ethernet1 -Dhcp Enabled
#De interface wordt hernoemd naar WAN
Rename-NetAdapter “Ethernet1” -NewName “WAN"
#Hiermee wordt IPv6 op alle adapters uitgeschakeld
Disable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip6

#De inhoud van de object wordt geprint in groene tekst
Write-host -ForegroundColor green -Object "Active Directory wordt gedownloadt en geinstalleerd"
#Met deze commando wordt Active Directory domain services geinstalleerd
Add-WindowsFeature AD-Domain-Services –IncludeManagementTools


#De inhoud van de object wordt geprint in groene tekst
Write-host -ForegroundColor green -Object "DNS wordt geinstalleerd"
#DNS service wordt geinstalleerd
Install-WindowsFeature DNS –IncludeManagementTools



Write-Host -ForegroundColor Green -object "De Computer gaat over 60 sec herstarten!!!!!"
Start-Sleep -Seconds 60
Restart-Computer
