#Huidige versie v0.1

#versie v0.1, script is aangemaakt
#versie v0.2, LAN netwerk is geautomatiseerd
#versie v0.3, 
#versie v1.0, fine tunes, eind versie

#Variabelen worden gedefineerd
$domain = "AventusRocks162910.local"
$user = "Administrator"
$Passowrd = Read-Host "Typ de wachtwoord van de $user account" -AsSecureString
$username = "$domain\$user"
$credentials = New-Object System.Management.Automation.PSCredential($username,$Passowrd)

#Computer wordt toegevoegd aan domein
Write-Host -BackgroundColor Green "Computer wordt nu aan domein toegevoegd"
Add-Computer -DomainName $domain -Credential $credentials

Write-host -ForegroundColor red -Object "Computer gaat opnieuw opstarten binnen 15 sec"
Start-Sleep -Seconds 15
Restart-Computer