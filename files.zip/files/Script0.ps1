#Huidige versie v0.3

#versie v0.1, script is aangemaakt
#versie v0.2, De timezone wordt ingesteld, de computernaam wordt ingesteld


#Deze script stelt de volgende in:
#                          timezone van de computer in
#                          hostnaam van de computer in

#Hiermee wordt de timezone ingesteld in Europe standart time UTC +1
Set-TimeZone -Id "W. Europe Standard Time"


#De inhoud van de variable IPLAN wordt geprint in groene tekst
Write-host -ForegroundColor green -Object "De IP adres van de LAN wordt ingesteld"
#Hier wordt de LAN adapter geconfigureerd
$IPLAN = "172.16.2.10"
New-NetIPAddress -InterfaceAlias "Ethernet0" -IPAddress $IPLAN -PrefixLength 24


#De Computer naam wordt aangepast naar DC162910
Rename-Computer -NewName DC162910 