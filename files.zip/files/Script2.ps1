#Huidige versie v1.2

#versie v0.1, script is aangemaakt
#versie v0.2, DHCP is geconfigureerd en getest, Rollen zijn geinstalleerd
#versie v0.3, Printer toegevoegd met driver en instellingen
#versie v1.0, eindversie
#versie v1.1, DHCP autorisatie code is eruit gehaald
#versie v1.2, Routing and remote access features zijn toegevoegd aan de script

#Variabelen worden gedefinieerd
$IPLAN = "172.16.2.10"
$GWLAN = "172.16.2.10"
$DNS1LAN = "1.1.1.1"
$DNS2LAN = "8.8.8.8"
$HostName = "DC162910"
$DomainName = "AventusRocks162910.local"
$DomainNetBiosName = "AventusRocks"
$IPPrinter = "172.16.2.110"
$url = "https://ftp.hp.com/pub/softlib/software13/COL40842/ds-99374-24/upd-pcl6-x64-7.0.1.24923.exe"
$dest = "c:\HP\upd-pcl6-x64-7.0.1.24923.zip"

#Hiermee wordt DHCP geinstalleerd
Write-Host -ForegroundColor Green -Object "DHCP wordt geïnstalleerd"
Install-WindowsFeature -Name 'DHCP' –IncludeManagementTools

#Hiermee wordt de scope gedefenieerd
Write-Host -ForegroundColor Green -Object "DHCP scope wordt gedefinieerd"
Add-DhcpServerV4Scope -Name "DHCP Scope" -StartRange 172.16.2.100 -EndRange 172.16.2.150 -SubnetMask 255.255.255.0

#De router en DNS wordt geconfigureerd
Write-Host -ForegroundColor Green -Object "DNS en router wordt geconfigureerd in de DHCP instellingen"
Set-DhcpServerV4OptionValue -DnsServer 172.16.2.10 -Router 172.16.2.10

#Lease wordt ingesteld
Write-Host -ForegroundColor Green -Object "Lease Time in de DHCP wordt ingesteld"
Set-DhcpServerv4Scope -ScopeId 172.16.2.10 -LeaseDuration 1.00:00:00

#DHCP reservering voor de printer HP Laserjet m118dw
Write-Host -ForegroundColor Green -Object "Een DHCP Reservering voor de printer wordt ingesteld"
Add-DhcpServerv4Reservation -ScopeId 172.16.2.10 -IPAddress $IPPrinter -ClientId "B0-1C-38-0A-FB-24" -Description "Reservation for de printer HP Laserjet m118dw"


#DHCP service wordt opnieuw opgestart
Write-Host -ForegroundColor Green -Object "DHCP wordt opnieuw opgestart"
Restart-service dhcpserver


#Install router and remote access service
Write-Host -ForegroundColor Green -Object "De role Router and Remote Access wordt gedownloadt en geïnstalleerd"
Install-WindowsFeature RemoteAccess –IncludeManagementTools
Install-WindowsFeature -Name DirectAccess-VPN
Install-WindowsFeature -Name Routing
Install-WindowsFeature RSAT-RemoteAccess-PowerShell


#Install print service
Write-Host -ForegroundColor Green -Object "Print service wordt geïnstalleerd"
Install-WindowsFeature Print-Services –IncludeManagementTools

#Een map aanmaken genaamd HP in de path C:\HP
Write-Host -ForegroundColor Green -Object "Een map aanmaken voor de HP driver"
New-Item -ItemType directory -path C:\HP

#Bestand (driver) downloaden vanaf HP website
Write-Host -ForegroundColor Green -Object "De Driver wordt gedownloadt"
Invoke-WebRequest -Uri $url -OutFile $dest

#Bestand Uitpakken
Write-Host -ForegroundColor Green -Object "De printer driver wordt uitgepakt"
Expand-Archive C:\HP\upd-pcl6-x64-7.0.1.24923.zip -Force -DestinationPath "C:\HP Universal Print Driver"

#De map NETLOGON wordt gemaakt
Write-Host -ForegroundColor Green -Object "De map NETLOGON wordt gemaakt"
New-Item -ItemType directory -path "C:\Windows\NETLOGON"

#driver kopieren naar NETLOGON voor gebruikers die geen lid zijn van het domein
Write-Host -ForegroundColor Green -Object "De Driver wordt gekopieerd naar de NETLOGON"
Copy-Item -Path "C:\HP Universal Print Driver\hpcu255u.inf" -Destination "C:\Windows\NETLOGON"

#Hier wordt de printer driver toegevoegd aan de store
Write-Host -ForegroundColor Green -Object "De Driver wordt toegevoegd aan de store"
pnputil.exe -i -a "C:\HP Universal Print Driver\hpcu255u.inf"

#De Print Driver wordt toegevoegd aan de lijst met drivers
Write-Host -ForegroundColor Green -Object "De Driver wordt toegevoegd aan de lijst met drivers"
Add-PrinterDriver -Name “HP Universal Printing PCL 6”

#Hier wordt een printer port aangemaakt
Write-Host -ForegroundColor Green -Object "De printer port wordt nu aangemaakt"
Add-PrinterPort -Name "TCPPort:" -PrinterHostAddress "172.16.2.110"

#Hier wordt de printer toegevoegd
Write-Host -ForegroundColor Green -Object "De printer wordt nu aangemaakt"
Add-Printer -Name "Printer" -DriverName "HP Universal Printing PCL 6" -PortName "TCPPort:"

#De printer papier instellen
Write-Host -ForegroundColor Green -Object "De papier type wordt ingesteld in de nieuwe printer"
Set-PrintConfiguration -PrinterName "Printer" -PaperSize A4

#Printer configureren met de instellingen
Write-Host -ForegroundColor Green -Object "De instellingen van de nieuwe printer worden ingesteld"
Set-Printer -Name "Printer" -Shared $True -ShareName "Printer" -RenderingMode SSR

#Hier wordt de server geconfigureerd als een DC
Write-Host -ForegroundColor Green -Object "De Server wordt geconfigureerd als een DC"
Write-Host -ForegroundColor Red -Object "Je wordt nu gevraagd om een wachtwoord in te voeren, houd even rekening mee, deze wachtwoord is heel belangrijk, bewaar dit wachtwoord goed"
Install-ADDSForest -DomainName AventusRocks162910.local -DomainNetbiosName AventusRocks -InstallDNS
