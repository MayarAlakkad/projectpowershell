#Huidige versie v3.0

#versie v0.1, script is aangemaakt, ou's en groepen worden aangemaakt
#versie v0.2, Loop aangemaakt voor de NTFS rechten
#versie v0.3, gebruikers toegevoegd en rechten toegewezen
#versie v0.4, comments zijn toegevoegd aan de script
#versie v1.0, eindversie
#versie v2.0, de loop gebruikerstoevoegen is aangepast
#versie v2.1, een nieuwe loop voor de userfolders is aangemaakt
#versie v2.2, rechten van de userfolders, userproflies en shares is aangepast
#versie v2.3, GPO is aangemaakt voor de printer
#versie v3.0, eindversie, commentaar is toegevoegd

#Variabelen worden gedefinieerd
$IPLAN = "172.16.2.10"
$GWLAN = "172.16.2.10"
$DNS1LAN = "1.1.1.1"
$DNS2LAN = "8.8.8.8"
$HostName = "DC162910"
$DomainName = "AventusRocks162910.local"
$DomainNetBiosName = "AventusRocks"
$gitLocatie = "https://raw.githubusercontent.com/MayarAlakkad/projectpowershell/main/files.zip"
$downloadLocatie = "C:\Test\files.zip"


#OU's worden aangemaakt
Write-Host -ForegroundColor Green -Object "OU's worden aangemaakt"
New-ADOrganizationalUnit -Name "Afdelingen" -Path "DC=AventusRocks162910,DC=local"
New-ADOrganizationalUnit -Name "Directie" -Path "OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADOrganizationalUnit -Name "Staf" -Path "OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADOrganizationalUnit -Name "Verkoop" -Path "OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADOrganizationalUnit -Name "Administratie" -Path "OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADOrganizationalUnit -Name "FabricageBudel" -Path "OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADOrganizationalUnit -Name "Automatisering" -Path "OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADOrganizationalUnit -Name "Productie" -Path "OU=Afdelingen,DC=AventusRocks162910,DC=local"


#Globale groepen worden aangemaakt
Write-Host -ForegroundColor Green -Object "De GG groepen worden aangemaakt"
New-ADGroup -Name "GG_staf" -GroupCategory Security -GroupScope Global -DisplayName "GG_Staf" -Path "OU=Staf,OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADGroup -Name "GG_Verkoop" -GroupCategory Security -GroupScope Global -DisplayName "GG_Verkoop" -Path "OU=Verkoop,OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADGroup -Name "GG_Directie" -GroupCategory Security -GroupScope Global -DisplayName "GG_Directie" -Path "OU=Directie,OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADGroup -Name "GG_FabricageBudel" -GroupCategory Security -GroupScope Global -DisplayName "GG_FabricageBudel" -Path "OU=FabricageBudel,OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADGroup -Name "GG_Administratie" -GroupCategory Security -GroupScope Global -DisplayName "GG_Administratie" -Path "OU=Administratie,OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADGroup -Name "GG_Automatisering" -GroupCategory Security -GroupScope Global -DisplayName "GG_Automatisering" -Path "OU=Automatisering,OU=Afdelingen,DC=AventusRocks162910,DC=local"
New-ADGroup -Name "GG_Productie" -GroupCategory Security -GroupScope Global -DisplayName "GG_Productie" -Path "OU=Productie,OU=Afdelingen,DC=AventusRocks162910,DC=local"


#Disk wordt geformateerd
Write-Host -ForegroundColor Green -Object "De schijf wordt geformateerd"
Get-Disk
$Disk = Read-Host -Prompt 'Type the disknumber that you want to format'
Initialize-Disk -Number $Disk
new-partition -disknumber $Disk -usemaximumsize | format-volume -filesystem NTFS -newfilesystemlabel Data
get-partition -disknumber $Disk | set-partition -newdriveletter L


#Mappen voor de shares worden aangemaakt
Write-Host -ForegroundColor Green -Object "De mappen userfolder, userprofiles en bedrijfsshares worden aangemaakt"
New-Item -ItemType directory -Name Shares -Path L:\
New-Item -ItemType directory -Name Shares -Path L:\Shares
New-Item -ItemType directory -Name UserProfiles -Path L:\Shares
New-Item -ItemType directory -Name UserFolders -Path L:\Shares
New-Item -ItemType directory -Name Administratie -Path L:\Shares\Shares
New-Item -ItemType directory -Name Directie -Path L:\Shares\Shares
New-Item -ItemType directory -Name Verkoop -Path L:\Shares\Shares
New-Item -ItemType directory -Name Automatisering -Path L:\Shares\Shares
New-Item -ItemType directory -Name FabricageBudel -Path L:\Shares\Shares
New-Item -ItemType directory -Name Staf -Path L:\Shares\Shares
New-Item -ItemType directory -Name Productie -Path L:\Shares\Shares


#DL groepen worden aangemaakt voor alle afdelingen
Write-Host -ForegroundColor Green -Object "DL groepen worden angemaakt voor alle afdelingen"
New-ADGroup -Name "DL_Staf-Share_R" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Staf-Share_R"
New-ADGroup -Name "DL_Staf-Share_W" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Staf-Share_W"

New-ADGroup -Name "DL_Verkoop-Share_R" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Verkoop-Share_R"
New-ADGroup -Name "DL_Verkoop-Share_W" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Verkoop-Share_W"

New-ADGroup -Name "DL_Directie-Share_R" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Directie-Share_R"
New-ADGroup -Name "DL_Directie-Share_W" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Directie-Share_W"

New-ADGroup -Name "DL_FabricageBudel-Share_R" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_FabricageBudel-Share_R"
New-ADGroup -Name "DL_FabricageBudel-Share_W" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_FabricageBudel-Share_W"

New-ADGroup -Name "DL_Administratie-Share_R" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Administratie-Share_R"
New-ADGroup -Name "DL_Administratie-Share_W" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Administratie-Share_W"

New-ADGroup -Name "DL_Automatisering-Share_R" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Automatisering-Share_R"
New-ADGroup -Name "DL_Automatisering-Share_W" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Automatisering-Share_W"

New-ADGroup -Name "DL_Productie-Share_R" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Productie-Share_R"
New-ADGroup -Name "DL_Productie-Share_W" -GroupCategory Security -GroupScope DomainLocal -DisplayName "DL_Productie-Share_W"


#DL rechten worden toegewezen aan de globale groepen
Write-Host -ForegroundColor Green -Object "DL groepen worden toegewezen aan de globle groepen"
Add-AdGroupMember -Identity DL_Directie-Share_W -Members GG_Directie
Add-AdGroupMember -Identity DL_Directie-Share_R -Members GG_Directie, GG_Verkoop, GG_Administratie, GG_Automatisering, GG_FabricageBudel, GG_Staf, GG_Productie
Add-AdGroupMember -Identity DL_Administratie-Share_W -Members GG_Administratie
Add-AdGroupMember -Identity DL_Administratie-Share_R -Members GG_Directie, GG_Verkoop, GG_Administratie, GG_Automatisering, GG_FabricageBudel, GG_Staf, GG_Productie
Add-AdGroupMember -Identity DL_Verkoop-Share_W -Members GG_Verkoop
Add-AdGroupMember -Identity DL_Verkoop-Share_R -Members GG_Directie, GG_Verkoop, GG_Administratie, GG_Automatisering, GG_FabricageBudel, GG_Staf, GG_Productie
Add-AdGroupMember -Identity DL_Staf-Share_W -Members GG_Staf
Add-AdGroupMember -Identity DL_Staf-Share_R -Members GG_Directie, GG_Verkoop, GG_Administratie, GG_Automatisering, GG_FabricageBudel, GG_Staf, GG_Productie
Add-AdGroupMember -Identity DL_FabricageBudel-Share_W -Members GG_FabricageBudel
Add-AdGroupMember -Identity DL_FabricageBudel-Share_R -Members GG_Directie, GG_Verkoop, GG_Administratie, GG_Automatisering, GG_FabricageBudel, GG_Staf, GG_Productie
Add-AdGroupMember -Identity DL_Automatisering-Share_W -Members GG_Automatisering
Add-AdGroupMember -Identity DL_Automatisering-Share_R -Members GG_Directie, GG_Verkoop, GG_Administratie, GG_Automatisering, GG_FabricageBudel, GG_Staf, GG_Productie
Add-AdGroupMember -Identity DL_Productie-Share_W -Members GG_Productie
Add-AdGroupMember -Identity DL_Productie-Share_R -Members GG_Directie, GG_Verkoop, GG_Administratie, GG_Automatisering, GG_FabricageBudel, GG_Staf, GG_Productie


#SMB shares worden aangemaakt
Write-Host -ForegroundColor Green -Object "SMB shares worden aangemaakt"
New-SmbShare -Path L:\Shares\Shares -Name "Shares" -ChangeAccess "Domain Users" -FullAccess "Domain Admins"
New-SmbShare -Path L:\Shares\UserFolders -Name "UserFolders$" -ChangeAccess "Domain Users" -FullAccess "Domain Admins"
New-SmbShare -Path L:\Shares\UserProfiles -Name "UserProfiles$" -ChangeAccess "Domain Users" -FullAccess "Domain Admins"

#Inheritence uitschakelen en gebruiker domain admin toevoegen
Write-Host -ForegroundColor Green -Object "Inheritence wordt uitgeschakeld op de share map en de domain admin krijgt full-control rechten"
$folder = 'L:\Shares\Shares'
$acl = Get-ACL -Path $folder
$acl.SetAccessRuleProtection($True, $False)
Set-Acl -Path $folder -AclObject $acl

$acl = Get-Acl L:\Shares\Shares
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Domain Admins","FullControl","Allow")
$acl.SetAccessRule($AccessRule)
$acl | Set-Acl L:\Shares\Shares

$acl = Get-Acl L:\Shares\Shares
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Domain Users","Read","Allow")
$acl.SetAccessRule($AccessRule)
$acl | Set-Acl L:\Shares\Shares

#DL groepen worden toegewezen aan de shares
Write-Host -ForegroundColor Green -Object "De DL groepen worden aan de juiste share map toegewezen"
while(($inp = Read-Host -Prompt "Do you want to add permissions to shared folder, if not type Q") -ne "Q"){
    
    $path = Read-Host -Prompt 'Type the filename (shared folder name).'

    $acl = Get-Acl L:\Shares\Shares\$path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("DL_$path-share_R","Read","Allow")
    $acl.SetAccessRule($AccessRule)
    $acl | Set-Acl L:\Shares\Shares\$path

    $acl = Get-Acl L:\Shares\Shares\$path
    $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("DL_$path-share_W","Readandexecute,write","Allow")
    $acl.SetAccessRule($AccessRule)
    $acl | Set-Acl L:\Shares\Shares\$path

   }


Write-Host -ForegroundColor Green -Object "De rechten van de userfolders en userprofiles worden nu gedefineerd"
$folder = 'L:\Shares\UserFolders'
$acl = Get-ACL -Path $folder
$acl.SetAccessRuleProtection($True, $False)
Set-Acl -Path $folder -AclObject $acl

$acl = Get-Acl L:\Shares\UserFolders
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Domain Admins","FullControl","Allow")
$acl.SetAccessRule($AccessRule)
$acl | Set-Acl L:\Shares\UserFolders

$folder = 'L:\Shares\UserProfiles'
$acl = Get-ACL -Path $folder
$acl.SetAccessRuleProtection($True, $False)
Set-Acl -Path $folder -AclObject $acl

$acl = Get-Acl L:\Shares\UserProfiles
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Domain Admins","FullControl","Allow")
$acl.SetAccessRule($AccessRule)
$acl | Set-Acl L:\Shares\UserProfiles

$acl = Get-Acl L:\Shares\UserProfiles
$AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("Domain Users","Readandexecute,write","Allow")
$acl.SetAccessRule($AccessRule)
$acl | Set-Acl L:\Shares\UserProfiles


#Een map wordt aangemaakt voor de csv bestand
Write-Host -ForegroundColor Green -Object "De bestanden worden nu vanuit github gedownloadt"
New-Item -ItemType Directory -Path C:\Test

#CSV bestand wordt gedownloadt
Invoke-WebRequest -Uri $gitLocatie -OutFile $downloadLocatie
Expand-Archive C:\Test\files.zip -Force -DestinationPath "C:\Test\files"

#Gebruikers worden toegevoegd
Import-Module activedirectory 
Write-Host -ForegroundColor Green -Object "Gebruikers worden nu aangemaakt"

#Bestand CSV wordt geïmporteerd
$ADUsers = Import-csv C:\Test\files\gebruikers.csv 
 
#een loop start voor het toevoegen van de gebruikers 
foreach ($User in $ADUsers) 
{ 
 
$Username 	= $User.username 
$Password 	= $User.password 
$Firstname 	= $User.firstname 
$Lastname 	= $User.lastname 
$OU 		= $User.ou #This field refers to the OU the user account is to be created in 
$email      = $User.email 
$streetaddress = $User.streetaddress 
$city       = $User.city 
$zipcode    = $User.zipcode 
$state      = $User.state 
$country    = $User.country 
$telephone  = $User.telephone 
$jobtitle   = $User.jobtitle 
$company    = $User.company 
$department = $User.department 
$profilePath = "\\DC162910\UserProfiles$\$Username"
$driveLetter = $User.HomeDrive
$homeDirectory = "\\DC162910\UserFolders$\$Username"
 
#Checken of de gebruiker al bestaat in de AD
if (Get-ADUser -F {SamAccountName -eq $Username}) 
{ 
 Write-Warning "A user account with username $Username already exist in Active Directory." 
} 
else 
{ 
#Als de gebruiker niet bestaat, maak de gebruiker
New-ADUser -SamAccountName $Username `
            -UserPrincipalName "$Username@AventusRocks162910.local" `
            -Name "$Firstname $Lastname" `
            -GivenName $Firstname `
            -Surname $Lastname `
            -Enabled $True `
            -DisplayName "$Lastname, $Firstname" `
            -City $city `
            -Company $company `
            -State $state `
            -StreetAddress $streetaddress `
            -OfficePhone $telephone `
            -Path $OU `
            -EmailAddress $email `
            -Title $jobtitle `
            -Department $department `
            -AccountPassword (convertto-securestring $Password -AsPlainText -Force) `
            -ChangePasswordAtLogon $True `
            -ProfilePath $profilePath `
            -HomeDirectory $homeDirectory `
            -HomeDrive Z:;
           
}
}

#UserFolders worden aangemaakt
Write-Host -ForegroundColor Green -Object "Usersfolders worden aangemaakt"
If (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
 {  
 Cls  
  Write-warning "This script needs to be run As Admin go back and Run as admin"
Start-Sleep -Seconds 5
Exit
 }
$users=get-aduser -filter * 
Foreach($user in $users)
{
$user=$user.samaccountname
$HomeDir ="\\DC162910\UserFolders$\$($user)" -f $user; <#change it with your servername with actual server I am using the local computer itself in this example #>
Set-ADUser $user -HomeDirectory $HomeDir -HomeDrive z;
if (-not (Test-Path "$homedir"))
        {
    $acl = Get-Acl (New-Item -Path $homedir -ItemType Directory)

     # Make sure access rules inherited from parent folders.
    $acl.SetAccessRuleProtection($false, $true)

    $ace = "$domain\$user","FullControl", "ContainerInherit,ObjectInherit","None","Allow"
    $objACE = New-Object System.Security.AccessControl.FileSystemAccessRule($ace)
    $acl.AddAccessRule($objACE)
 Set-ACL -Path "$homedir" -AclObject $acl
}}


#De gebruikers in de OU's worden toegevoegd aan de juiste Globale groep
Write-Host -ForegroundColor Green -Object "De gebruikers worden op de juiste GG groep toegevoegd"
Get-ADUser -SearchBase ‘OU=Directie,OU=Afdelingen,DC=AventusRocks162910,DC=local’ -Filter * | ForEach-Object {Add-ADGroupMember -Identity ‘GG_Directie’ -Members $_ }
Get-ADUser -SearchBase ‘OU=Automatisering,OU=Afdelingen,DC=AventusRocks162910,DC=local’ -Filter * | ForEach-Object {Add-ADGroupMember -Identity ‘GG_Automatisering’ -Members $_ }
Get-ADUser -SearchBase ‘OU=Verkoop,OU=Afdelingen,DC=AventusRocks162910,DC=local’ -Filter * | ForEach-Object {Add-ADGroupMember -Identity ‘GG_Verkoop’ -Members $_ }
Get-ADUser -SearchBase ‘OU=FabricageBudel,OU=Afdelingen,DC=AventusRocks162910,DC=local’ -Filter * | ForEach-Object {Add-ADGroupMember -Identity ‘GG_FabricageBudel’ -Members $_ }
Get-ADUser -SearchBase ‘OU=Staf,OU=Afdelingen,DC=AventusRocks162910,DC=local’ -Filter * | ForEach-Object {Add-ADGroupMember -Identity ‘GG_Staf’ -Members $_ }
Get-ADUser -SearchBase ‘OU=Productie,OU=Afdelingen,DC=AventusRocks162910,DC=local’ -Filter * | ForEach-Object {Add-ADGroupMember -Identity ‘GG_Productie’ -Members $_ }
Get-ADUser -SearchBase ‘OU=Administratie,OU=Afdelingen,DC=AventusRocks162910,DC=local’ -Filter * | ForEach-Object {Add-ADGroupMember -Identity ‘GG_Administratie’ -Members $_ }

#GPO aanmaken voor printer toevoegen voor de gebruikers
Write-Host -ForegroundColor Green -Object "De GPO voor het aanmelden van de printer wordt toegevoegd"
new-gpo -name Printer-Policy | new-gplink -target "ou=afdelingen,dc=AventusRocks162910,dc=local"
Import-GPO -BackupGpoName "Printer Policy" -TargetName "Printer-Policy" -Path C:\Test\files